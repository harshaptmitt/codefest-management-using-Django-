from django.contrib import admin
from .models import TeamRegister,Feedback

admin.site.register(TeamRegister)
admin.site.register(Feedback)
